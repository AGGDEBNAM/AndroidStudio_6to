package com.example.mod;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;

    EditText nombre, mascota, raza, anios, tel;

    Button btnAnterior, btnCambios, btnSiguiente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nombre = findViewById(R.id.cliente);
        mascota = findViewById(R.id.mascota);
        raza = findViewById(R.id.raza);
        anios = findViewById(R.id.anios);
        tel = findViewById(R.id.tel);
        btnAnterior = findViewById(R.id.btnAnterior);
        btnCambios = findViewById(R.id.btnCambios);
        btnSiguiente = findViewById(R.id.btnSiguiente);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.registro){

        }
        if(item.getItemId() == R.id.ver){

        }
        return super.onOptionsItemSelected(item);
    }
}