package com.example.suma;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.inputmethod.InputMethodManager;
import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    private EditText number1EditText;
    private EditText number2EditText;
    private TextView resultTextView;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number1EditText = findViewById(R.id.number1EditText);
        number2EditText = findViewById(R.id.number2EditText);
        resultTextView = findViewById(R.id.resultTextView);
        calculateButton = findViewById(R.id.calculateButton);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateSum();
            }
        });

        View transparentView = findViewById(R.id.transparentView);
        transparentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
            }
        });

    }

    private void calculateSum() {
        String num1Str = number1EditText.getText().toString();
        String num2Str = number2EditText.getText().toString();

        EditText decimalsEditText = findViewById(R.id.decimalsEditText);
        String decimalsStr = decimalsEditText.getText().toString();

        if (decimalsStr.isEmpty()) {
            decimalsStr = decimalsEditText.getTag().toString();
        }

        int decimals = Integer.parseInt(decimalsStr);

        if (decimals < 0) {
            decimals = 0;
        } else if (decimals > 6) {
            decimals = 6;
        }

        if (!num1Str.isEmpty() && !num2Str.isEmpty()) {
            double num1 = Double.parseDouble(num1Str);
            double num2 = Double.parseDouble(num2Str);
            double sum = num1 + num2;

            // Crea un DecimalFormat con el patrón de la cantidad de decimales especificada
            String pattern = "#." + new String(new char[decimals]).replace('\0', '0');
            DecimalFormat decimalFormat = new DecimalFormat(pattern);

            // Formatea la suma con la cantidad de decimales especificada
            String formattedSum = decimalFormat.format(sum);

            resultTextView.setText(" " + formattedSum);
        } else {
            resultTextView.setText("Insert 2");
        }
    }


    private void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
