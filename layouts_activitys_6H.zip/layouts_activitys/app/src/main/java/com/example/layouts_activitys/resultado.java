package com.example.layouts_activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

public class resultado extends AppCompatActivity {

    private TextView TextViewResultado;
    private String Output;
    private Double Convert;
    private Double Term;
    private String Res;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        TextViewResultado = findViewById(R.id.TextView_Resultado);

        Traspaso();
    }

    private void Traspaso() {
        Output = getIntent().getStringExtra("dato");
        Convert = Double.parseDouble(Output);
        Term = Convert + 12.4 + 45 + 50 + 5.5;
        Res = " " + Term;
        TextViewResultado.setText(Res);
    }

}