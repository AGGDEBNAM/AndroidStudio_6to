package com.example.layouts_activitys;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class resultado extends AppCompatActivity {

    private TextView TextViewResultado;
    private String Output;
    private Double Convert;
    private Double Term;
    private String Res;

    private Toolbar toolbar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        TextViewResultado = findViewById(R.id.TextView_Resultado);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Traspaso();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId()==R.id.Ayuda){
            Intent Menu_suma = new Intent(this, resultado.class);
            startActivity(Menu_suma);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void Traspaso() {
        Output = getIntent().getStringExtra("dato");
        Convert = Double.parseDouble(Output);
        Term = Convert + 12.4 + 45 + 50 + 5.5;
        Res = " " + Term;
        TextViewResultado.setText(Res);
    }

}