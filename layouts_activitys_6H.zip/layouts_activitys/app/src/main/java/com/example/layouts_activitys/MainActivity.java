package com.example.layouts_activitys;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private EditText EditTextInput;
    private Button BtnInput;
    private Toolbar toolbar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditTextInput = findViewById(R.id.EditText_Input);
        BtnInput = findViewById(R.id.Btn_Input);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        BtnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClick_sumar();
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id ==R.id.Ayuda){
            Intent intent_resultado = new Intent(this, resultado.class);
            startActivity(intent_resultado);
            return true;
        }else if (id == R.id.Creador) {
            Intent intent_menu = new Intent(this, MainActivity.class);
            startActivity(intent_menu);
            return true;
        } else if (id == R.id.Resultado) {
            Intent intent_mas = new Intent(this, resultado.class);
            startActivity(intent_mas);
            return true;
        }else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void onClick_sumar() {
        Intent suma = new Intent(this,resultado.class);
        suma.putExtra("dato",EditTextInput.getText().toString());
        startActivity(suma);
    }
}