package com.example.layouts_activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private EditText EditTextInput;
    private Button BtnInput;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditTextInput = findViewById(R.id.EditText_Input);
        BtnInput = findViewById(R.id.Btn_Input);

        BtnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClick_sumar();
            }
        });


    }

    private void onClick_sumar() {
        Intent suma = new Intent(this,resultado.class);
        suma.putExtra("dato",EditTextInput.getText().toString());
        startActivity(suma);
    }
}