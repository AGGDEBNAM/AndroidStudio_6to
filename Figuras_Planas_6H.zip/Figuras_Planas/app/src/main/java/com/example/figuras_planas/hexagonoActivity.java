package com.example.figuras_planas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class hexagonoActivity extends AppCompatActivity {

    private EditText ladoEditText;
    private EditText alturaEditText;
    private TextView circunferenciaTextView;
    private TextView areaTextView;
    private TextView volumenTextView;
    private TextView MostrarProcedimiento;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hexagono);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(hexagonoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        ladoEditText = findViewById(R.id.hexagono_lado);
        alturaEditText = findViewById(R.id.hexagono_altura);
        circunferenciaTextView = findViewById(R.id.hexagono_circunferencia);
        areaTextView = findViewById(R.id.hexagono_area);
        volumenTextView = findViewById(R.id.hexagono_volumen);
        MostrarProcedimiento = findViewById(R.id.procedimientos_text_view);

        ladoEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calcularResultados(charSequence.toString(), alturaEditText.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        alturaEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calcularResultados(ladoEditText.getText().toString(), charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_figuras) {
            Intent intentMain = new Intent(this, MainActivity.class);
            startActivity(intentMain);
            return true;
        } else if (id == R.id.hexagono_figuras) {
            Intent intentHexagono = new Intent(this, hexagonoActivity.class);
            startActivity(intentHexagono);
            return true;
        } else if (id == R.id.circulo_figuras) {
            Intent intentCirculo = new Intent(this, circuloActivity.class);
            startActivity(intentCirculo);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void calcularResultados(String ladoStr, String alturaStr) {
        if (!ladoStr.isEmpty() && !alturaStr.isEmpty()) {
            double lado = Double.parseDouble(ladoStr);
            double altura = Double.parseDouble(alturaStr);

            double perimetro = 6 * lado;

            double area = (3 * Math.sqrt(3) * Math.pow(lado, 2)) / 2;

            double volumen = (3 * Math.pow(lado, 2) / (2 * Math.tan(Math.toRadians(30)))) * altura;

            circunferenciaTextView.setText(String.format("%.3f m", perimetro));
            areaTextView.setText(String.format("%.3f m²", area));
            volumenTextView.setText(String.format("%.3f m³", volumen));

            String procedimientos = "Procedimientos:\n\n";
            procedimientos += "Perímetro:\n";
            procedimientos += "Perímetro = 6 * lado\n";
            procedimientos += "Perímetro = 6 * " + lado + "\n";
            procedimientos += "Perímetro = " + String.format("%.2f", perimetro) + " m\n\n";

            procedimientos += "Área:\n";
            procedimientos += "Área = (3 * √3 * lado²) / 2\n";
            procedimientos += "Área = (3 * √3 * " + lado + "²) / 2\n";
            procedimientos += "Área = " + String.format("%.2f", area) + " m²\n\n";

            procedimientos += "Volumen:\n";
            procedimientos += "Volumen = (3 × lado² / 2 × Tan(30°)) × largo\n";
            procedimientos += "Volumen = (3 × " + lado + "² / 2 × Tan(30°)) × " + altura + "\n";
            procedimientos += "Volumen = " + String.format("%.2f", volumen) + " m³\n";

            MostrarProcedimiento.setText(procedimientos);
        } else {
            circunferenciaTextView.setText("");
            areaTextView.setText("");
            volumenTextView.setText("");
        }
    }

}