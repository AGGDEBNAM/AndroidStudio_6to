package com.example.figuras_planas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class circuloActivity extends AppCompatActivity {

    private EditText radioEditText;
    private TextView circunferenciaTextView;
    private TextView areaTextView;
    private TextView volumenTextView;
    private TextView MostrarProcedimiento;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circulo);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(circuloActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        radioEditText = findViewById(R.id.circulo_radio);
        circunferenciaTextView = findViewById(R.id.circulo_circunferencia);
        areaTextView = findViewById(R.id.circulo_area);
        volumenTextView = findViewById(R.id.circulo_volumen);
        MostrarProcedimiento = findViewById(R.id.procedimientos_text_view);

        radioEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                calcularResultados(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_figuras) {
            Intent intentMain = new Intent(this, MainActivity.class);
            startActivity(intentMain);
            return true;
        } else if (id == R.id.hexagono_figuras) {
            Intent intentHexagono = new Intent(this, hexagonoActivity.class);
            startActivity(intentHexagono);
            return true;
        } else if (id == R.id.circulo_figuras) {
            Intent intentCirculo = new Intent(this, circuloActivity.class);
            startActivity(intentCirculo);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void calcularResultados(String radioStr) {
        if (!radioStr.isEmpty()) {
            double radio = Double.parseDouble(radioStr);
            double circunferencia = 2 * Math.PI * radio;
            double area = Math.PI * Math.pow(radio, 2);
            double volumen = (4.0 / 3.0) * Math.PI * Math.pow(radio, 3);

            circunferenciaTextView.setText(String.format("%.3f m", circunferencia));
            areaTextView.setText(String.format("%.3f m²", area));
            volumenTextView.setText(String.format("%.3f m³", volumen));

            String procedimientos = "Procedimientos:\n\n";
            procedimientos += "Circunferencia:\n";
            procedimientos += "Perímetro = 2 * π * radio\n";
            procedimientos += "Perímetro = 2 * π * " + radio + "\n";
            procedimientos += "Perímetro ≈ " + String.format("%.2f", circunferencia) + " m\n\n";

            procedimientos += "Área:\n";
            procedimientos += "Área = π * radio²\n";
            procedimientos += "Área = π * " + radio + "²\n";
            procedimientos += "Área ≈ " + String.format("%.2f", area) + " m²\n\n";

            procedimientos += "Volumen:\n";
            procedimientos += "Volumen = (4/3) * π * radio³\n";
            procedimientos += "Volumen = (4/3) * π * " + radio + "³\n";
            procedimientos += "Volumen ≈ " + String.format("%.2f", volumen) + " m³\n";

            MostrarProcedimiento.setText(procedimientos);

        } else {
            circunferenciaTextView.setText("");
            areaTextView.setText("");
            volumenTextView.setText("");
        }
    }

}