package com.example.figuras_planas;

import static com.example.figuras_planas.R.*;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

        ImageButton hexagonButton = findViewById(id.hexagono_button);
        ImageButton circleButton = findViewById(id.circulo_button);

        Toolbar toolbar = findViewById(id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        hexagonButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, hexagonoActivity.class);
                startActivity(intent);
            }
        });

        circleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, circuloActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_figuras) {
            Intent intentMain = new Intent(this, MainActivity.class);
            startActivity(intentMain);
            return true;
        } else if (id == R.id.hexagono_figuras) {
            Intent intentHexagono = new Intent(this, hexagonoActivity.class);
            startActivity(intentHexagono);
            return true;
        } else if (id == R.id.circulo_figuras) {
            Intent intentCirculo = new Intent(this, circuloActivity.class);
            startActivity(intentCirculo);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

}
