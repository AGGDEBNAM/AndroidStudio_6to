package com.example.generador_numeros;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class creador extends AppCompatActivity {

    Toolbar toolbar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creador);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id ==R.id.Ayuda){
            Intent intent_resultado = new Intent(this, ayuda.class);
            startActivity(intent_resultado);
            return true;
        }else if (id == R.id.Creador) {
            Intent intent_menu = new Intent(this, creador.class);
            startActivity(intent_menu);
            return true;
        } else if (id == R.id.Resultado) {
            Intent intent_mas = new Intent(this, MainActivity.class);
            startActivity(intent_mas);
            return true;
        }else {
            return super.onOptionsItemSelected(item);
        }
    }

}