package com.example.generador_numeros;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;





public class ayuda extends AppCompatActivity {

    private TextView mostrarAyuda;
    Toolbar toolbar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayuda);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mostrarAyuda = findViewById(R.id.ayuda_text_view);

        String ayudaText = "Instrucciones:\n\n";
        ayudaText += "Define los límites:\n" +
                "Escoge dos números que actuarán como límites para tu rango.\n" +
                "Asegúrate de que el primer número sea menor que el segundo número.\n\n";
        ayudaText += "Calcula el rango:\n" +
                "Presiona Calcular y te dara un mumero aleatorio.\n";

        mostrarAyuda.setText(ayudaText);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id ==R.id.Ayuda){
            Intent intent_resultado = new Intent(this, ayuda.class);
            startActivity(intent_resultado);
            return true;
        }else if (id == R.id.Creador) {
            Intent intent_menu = new Intent(this, creador.class);
            startActivity(intent_menu);
            return true;
        } else if (id == R.id.Resultado) {
            Intent intent_mas = new Intent(this, MainActivity.class);
            startActivity(intent_mas);
            return true;
        }else {
            return super.onOptionsItemSelected(item);
        }
    }
}