package com.example.generador_numeros;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText numero1EditText, numero2EditText;
    TextView resultadoTextView;
    Button generarBtn;
    View rootView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numero1EditText = findViewById(R.id.numero_1);
        numero2EditText = findViewById(R.id.numero_2);
        resultadoTextView = findViewById(R.id.resultado);
        generarBtn = findViewById(R.id.generar_btn);
        rootView = findViewById(android.R.id.content);

        rootView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideKeyboard();
                return false;
            }
        });

        generarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                hideKeyboard();
                generarNumeroAleatorio();
            }
        });
    }

    private void generarNumeroAleatorio() {
        String num1String = numero1EditText.getText().toString();
        String num2String = numero2EditText.getText().toString();

        if (num1String.isEmpty() || num2String.isEmpty()) {
            resultadoTextView.setText("Ingresa números en ambos campos.");
            return;
        }

        int num1 = Integer.parseInt(num1String);
        int num2 = Integer.parseInt(num2String);

        if (num1 >= num2 || num2 <= num1) {
            resultadoTextView.setText("El primer número debe ser menor que el segundo.");
            return;
        }

        Random random = new Random();
        int numeroAleatorio = random.nextInt((num2 - num1) + 1) + num1;

        resultadoTextView.setText(String.valueOf(numeroAleatorio));
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        View view = getCurrentFocus();
        if (view != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}

