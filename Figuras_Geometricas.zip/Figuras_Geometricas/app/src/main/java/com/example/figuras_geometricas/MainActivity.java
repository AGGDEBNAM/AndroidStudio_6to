package com.example.figuras_geometricas;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Spinner;
import android.view.inputmethod.InputMethodManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerMedidas;
    private ArrayAdapter<CharSequence> adapter;
    private EditText alturaRectanguloEditText;
    private EditText baseRectanguloEditText;
    private TextView areaCalculadarectanguloTextView;
    private TextView perimetroCalculadorectanguloTextView;
    private Button calculateButton_Rectangle;

    private EditText alturaTrianguloEditText;
    private EditText baseTrianguloEditText;
    private TextView areaCalculadatrianguloTextView;
    private TextView perimetroCalculadotrianguloTextView;
    private Button calculateButton_Triangle;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerMedidas = findViewById(R.id.spinnerMedidas);

        adapter = ArrayAdapter.createFromResource(this, R.array.sistemas_de_medidas, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMedidas.setAdapter(adapter);

        alturaRectanguloEditText = findViewById(R.id.alturarectanguloEditText);
        baseRectanguloEditText = findViewById(R.id.baserectanguloEditText);
        areaCalculadarectanguloTextView = findViewById(R.id.areaCalculadarectanguloTextView);
        perimetroCalculadorectanguloTextView = findViewById(R.id.perimetroCalculadorectanguloTextView);
        alturaTrianguloEditText = findViewById(R.id.alturatrianguloEditText);
        baseTrianguloEditText = findViewById(R.id.basetrianguloEditText);
        areaCalculadatrianguloTextView = findViewById(R.id.areaCalculadatrianguloTextView);
        perimetroCalculadotrianguloTextView = findViewById(R.id.perimetroCalculadotrianguloTextView);

        alturaRectanguloEditText.addTextChangedListener(textWatcher);
        baseRectanguloEditText.addTextChangedListener(textWatcher);
        alturaTrianguloEditText.addTextChangedListener(textWatcher);
        baseTrianguloEditText.addTextChangedListener(textWatcher);

        calculateButton_Rectangle = findViewById(R.id.calculateButton_1); // Encuentra el botón de cálculo para rectangulos
        calculateButton_Triangle = findViewById(R.id.calculateButton_2); // Encuentra el botón de cálculo para triangulos

        calculateButton_Rectangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAreaAndPerimeterRectangule();
            }
        });

        calculateButton_Triangle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateAreaAndPerimetertriangule();
            }
        });

        spinnerMedidas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String sistemaSeleccionado = parent.getItemAtPosition(position).toString();
                // Aquí puedes realizar acciones basadas en el sistema seleccionado
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Acciones cuando no se selecciona nada
            }
        });

        View transparentView = findViewById(R.id.transparentView);
        transparentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyboard();
            }
        });
    }

    private void hideKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // No se necesita implementar
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Cuando cambian los valores de los campos de texto, actualiza los cálculos
            calculateAreaAndPerimeterRectangule();
            calculateAreaAndPerimetertriangule();
        }

        @Override
        public void afterTextChanged(Editable s) {
            // No se necesita implementar
        }
    };

    private void calculateAreaAndPerimeterRectangule() {
        // Obtiene la selección del Spinner
        String sistemaSeleccionado = spinnerMedidas.getSelectedItem().toString();

        // Obtiene los valores de altura y base
        String R_alturaStr = alturaRectanguloEditText.getText().toString();
        String R_baseStr = baseRectanguloEditText.getText().toString();
        String T_alturaStr = alturaTrianguloEditText.getText().toString();
        String T_baseStr = baseTrianguloEditText.getText().toString();

        // Comprueba si los valores son válidos (no nulos ni vacíos)
        if (!R_alturaStr.isEmpty() && !R_baseStr.isEmpty()) {
            double altura = Double.parseDouble(R_alturaStr);
            double base = Double.parseDouble(R_baseStr);

            // Realiza la conversión de unidades según el sistema seleccionado
            double factorDeConversion = 1.0; // Por defecto, en metros
            if (sistemaSeleccionado.equals("Pies")) {
                factorDeConversion = 3.281; // 1 pie = 0.3048 metros
            } else if (sistemaSeleccionado.equals("Centímetros")) {
                factorDeConversion = 100; // 1 cm = 0.01 metros
            } else if (sistemaSeleccionado.equals("Pulgadas")) {
                factorDeConversion = 39.37; // 1 pulgada = 0.0254 metros
            }

            // Aplica el factor de conversión a la base
            base *= factorDeConversion;

            // Realiza los cálculos
            double area = altura * base;
            double perimetro = 2 * (altura + base);

            // Limita la cantidad de decimales en los resultados
            DecimalFormat decimalFormat = new DecimalFormat("#.##"); // Dos decimales
            String areaFormateada = decimalFormat.format(area);
            String perimetroFormateado = decimalFormat.format(perimetro);

            // Actualiza los campos de texto "Area calculada" y "Perímetro calculado"
            areaCalculadarectanguloTextView.setText(String.valueOf(areaFormateada));
            perimetroCalculadorectanguloTextView.setText(String.valueOf(perimetroFormateado));
        } else {
            // Si uno o ambos campos están vacíos, muestra un mensaje en los campos de resultado
            areaCalculadarectanguloTextView.setText("Ingrese valores válidos");
            perimetroCalculadorectanguloTextView.setText("Ingrese valores válidos");
        }

        if (!T_alturaStr.isEmpty() && !T_baseStr.isEmpty()) {
            double altura = Double.parseDouble(T_alturaStr);
            double base = Double.parseDouble(T_baseStr);

            // Realiza la conversión de unidades según el sistema seleccionado
            double factorDeConversion = 1.0; // Por defecto, en metros
            if (sistemaSeleccionado.equals("Pies")) {
                factorDeConversion = 3.281; // 1 pie = 0.3048 metros
            } else if (sistemaSeleccionado.equals("Centímetros")) {
                factorDeConversion = 100; // 1 cm = 0.01 metros
            } else if (sistemaSeleccionado.equals("Pulgadas")) {
                factorDeConversion = 39.37; // 1 pulgada = 0.0254 metros
            }

            // Aplica el factor de conversión a la base
            base *= factorDeConversion;

            // Realiza los cálculos
            double area = (altura * base) / 2.0;

            double baseCuadrado = Math.pow(base, 2); // Eleva al cuadrado
            double alturaCuadrado = Math.pow(altura, 2);

            double perimetro = Math.sqrt(baseCuadrado + alturaCuadrado); // Calcula la raíz cuadrada.

            // Limita la cantidad de decimales en los resultados
            DecimalFormat decimalFormat = new DecimalFormat("#.##"); // Dos decimales
            String areaFormateada = decimalFormat.format(area);
            String perimetroFormateado = decimalFormat.format(perimetro);

            // Actualiza los campos de texto "Area calculada" y "Perímetro calculado"
            areaCalculadatrianguloTextView.setText(String.valueOf(areaFormateada));
            perimetroCalculadotrianguloTextView.setText(String.valueOf(perimetroFormateado));
        } else {
            // Si uno o ambos campos están vacíos, muestra un mensaje en los campos de resultado
            areaCalculadatrianguloTextView.setText("Ingrese valores válidos");
            perimetroCalculadotrianguloTextView.setText("Ingrese valores válidos");
        }
    }

    private void calculateAreaAndPerimetertriangule() {
        // Obtiene la selección del Spinner
        String sistemaSeleccionado = spinnerMedidas.getSelectedItem().toString();

        // Obtiene los valores de altura y base
        String T_alturaStr = alturaTrianguloEditText.getText().toString();
        String T_baseStr = baseTrianguloEditText.getText().toString();

        if (!T_alturaStr.isEmpty() && !T_baseStr.isEmpty()) {
            double altura = Double.parseDouble(T_alturaStr);
            double base = Double.parseDouble(T_baseStr);

            // Realiza la conversión de unidades según el sistema seleccionado
            double factorDeConversion = 1.0; // Por defecto, en metros
            if (sistemaSeleccionado.equals("Pies")) {
                factorDeConversion = 3.281; // 1 pie = 0.3048 metros
            } else if (sistemaSeleccionado.equals("Centímetros")) {
                factorDeConversion = 100; // 1 cm = 0.01 metros
            } else if (sistemaSeleccionado.equals("Pulgadas")) {
                factorDeConversion = 39.37; // 1 pulgada = 0.0254 metros
            }

            // Aplica el factor de conversión a la base
            base *= factorDeConversion;

            // Realiza los cálculos
            double area = (altura * base) / 2.0;

            double baseCuadrado = Math.pow(base, 2); // Eleva al cuadrado
            double alturaCuadrado = Math.pow(altura, 2);

            double perimetro = Math.sqrt(baseCuadrado + alturaCuadrado); // Calcula la raíz cuadrada.

            // Limita la cantidad de decimales en los resultados
            DecimalFormat decimalFormat = new DecimalFormat("#.##"); // Dos decimales
            String areaFormateada = decimalFormat.format(area);
            String perimetroFormateado = decimalFormat.format(perimetro);

            // Actualiza los campos de texto "Area calculada" y "Perímetro calculado"
            areaCalculadatrianguloTextView.setText(String.valueOf(areaFormateada));
            perimetroCalculadotrianguloTextView.setText(String.valueOf(perimetroFormateado));
        } else {
            // Si uno o ambos campos están vacíos, muestra un mensaje en los campos de resultado
            areaCalculadatrianguloTextView.setText("Ingrese valores válidos");
            perimetroCalculadotrianguloTextView.setText("Ingrese valores válidos");
        }
    }

}



