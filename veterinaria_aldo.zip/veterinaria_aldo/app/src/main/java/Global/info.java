package Global;

import java.util.ArrayList;

import Pojo.Cliente;

public class info {

    public static final ArrayList<Cliente>Lista = new ArrayList<>();

}
