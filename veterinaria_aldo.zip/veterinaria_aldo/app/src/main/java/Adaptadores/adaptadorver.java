package Adaptadores;

import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class adaptadorver extends RecyclerView.Adapter<adaptadorver.Myactivity> {
    @NonNull
    @Override
    public adaptadorver.Myactivity onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull adaptadorver.Myactivity holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
        

    }

    public class Myactivity extends RecyclerView.ViewHolder{

        TextView


    }

}


