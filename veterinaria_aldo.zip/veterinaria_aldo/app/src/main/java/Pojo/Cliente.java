package Pojo;

public class Cliente {

    String NCliente;
    String NMascota;
    String Raza;
    String Year;

    public String getNCliente() {
        return NCliente;
    }

    public void setNCliente(String NCliente) {
        this.NCliente = NCliente;
    }

    public String getNMascota() {
        return NMascota;
    }

    public void setNMascota(String NMascota) {
        this.NMascota = NMascota;
    }

    public String getRaza() {
        return Raza;
    }

    public void setRaza(String raza) {
        Raza = raza;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

}
