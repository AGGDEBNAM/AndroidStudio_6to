package com.example.veterinaria_aldo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class recycler extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);
    }
}