package com.example.veterinaria_aldo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import Global.info;

public class MainActivity extends AppCompatActivity {

    Button agr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nom = findViewById();
        masc = findViewById();
        raz = findViewById();
        year = findViewById();
        agr = findViewById(R.id.btagregar);
        agr.setOnClickListener(R.id.setOn);
    }




    private void onClick_agregar(){


        info.Lista.add(masc);

        Toast.makeText(this, "se guardo", Toast.LENGTH_SHORT).show();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }






}