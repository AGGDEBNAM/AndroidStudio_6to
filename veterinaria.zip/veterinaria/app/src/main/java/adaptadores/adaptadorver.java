package adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.veterinaria.R;
import com.example.veterinaria.card;

import Global.info;

public class adaptadorver extends RecyclerView.Adapter<adaptadorver.Miactivity> {

    public Context context;
    @NonNull
    @Override
    public adaptadorver.Miactivity onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = View.inflate(context, R.layout.mi_vista, null);
        Miactivity obj = new Miactivity(v);
        return obj;
    }

    @Override
    public void onBindViewHolder(@NonNull adaptadorver.Miactivity MiActividad, int i) {
        final int pos = i;
        MiActividad.nom.setText(info.Lista.get(i).getNcliente());
        MiActividad.nommas.setText(info.Lista.get(i).getNmascota());
        MiActividad.nom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent card = new Intent(context, card.class);
                card.putExtra("pos", pos);
                context.startActivity(card);
            }
        });


    }

    @Override
    public int getItemCount() {
        return info.Lista.size();
    }

    public class Miactivity extends RecyclerView.ViewHolder{

        TextView nom, nommas;

        public Miactivity(@NonNull View itemView) {
            super(itemView);
            nom = itemView.findViewById(R.id.txtnom);
            nommas = itemView.findViewById(R.id.txtnmas);
        }
    }
}
