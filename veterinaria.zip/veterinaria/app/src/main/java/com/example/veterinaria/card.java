package com.example.veterinaria;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import Global.info;

public class card extends AppCompatActivity {

    TextView nombre, mascota, raza, anios, telefono;

    Button llamar;

    int posicion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card);

        nombre = findViewById(R.id.cliente1);
        mascota = findViewById(R.id.mascota1);
        raza = findViewById(R.id.raza1);
        anios = findViewById(R.id.anios1);
        telefono = findViewById(R.id.tel1);
        llamar = findViewById(R.id.btn_llamar);

        llamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClick_llama();
            }
        });

        posicion = getIntent().getIntExtra("pos", -1);
        nombre.setText(info.Lista.get(posicion).getNcliente());
        mascota.setText(info.Lista.get(posicion).getNmascota());
        raza.setText(info.Lista.get(posicion).getRaza());
        anios.setText(info.Lista.get(posicion).getYear());
        llamar.setText(info.Lista.get(posicion).getTelefono());

    }

    public void onClick_llama(){
        Intent llamar = new Intent(Intent.ACTION_CALL);
        llamar.setData(Uri.parse("tel:"+telefono.getText().toString()));
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CALL_PHONE}, 10);
            return;
        }
        startActivity(llamar);

    }



}