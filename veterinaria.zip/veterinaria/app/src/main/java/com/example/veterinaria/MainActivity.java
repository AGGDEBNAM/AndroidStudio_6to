package com.example.veterinaria;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import Global.info;
import Pojo.cliente;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;

    EditText nombre, mascota, raza, anios, tel;

    Button BtnAgregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nombre = findViewById(R.id.cliente);
        mascota = findViewById(R.id.mascota);
        raza = findViewById(R.id.raza);
        anios = findViewById(R.id.anios);
        tel = findViewById(R.id.tel);
        BtnAgregar = findViewById(R.id.BtnAgregar);

        BtnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onClick_agregar();
            }
        });

    }

    private void onClick_agregar() {

        String nombreCliente, nombreMascota, razaMascota, aniosMascota, numContacto;

        nombreCliente = nombre.getText().toString();
        nombreMascota = mascota.getText().toString();
        razaMascota = raza.getText().toString();
        aniosMascota = anios.getText().toString();
        numContacto = tel.getText().toString();

        if(nombreCliente.isEmpty() || nombreMascota.isEmpty() || razaMascota.isEmpty() || aniosMascota.isEmpty() || numContacto.isEmpty()){
            Toast.makeText(this, "Ingrese todos los datos", Toast.LENGTH_SHORT).show();
            return;
        }

        cliente mas = new cliente();
        mas.setNcliente(nombreCliente);
        mas.setNmascota(nombreMascota);
        mas.setRaza(razaMascota);
        mas.setYear(aniosMascota);
        mas.setTelefono(numContacto);

        info.Lista.add(mas);

        nombre.setText("");
        mascota.setText("");
        raza.setText("");
        anios.setText("");
        tel.setText("");

        Toast.makeText(this, "Datos guardados", Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.ver){
            Intent cambioC1 = new Intent(this, recycler.class);
            startActivity(cambioC1);
        }
        if(item.getItemId() == R.id.registro){
            Toast.makeText(this, "Ya estas en el registro", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }


}