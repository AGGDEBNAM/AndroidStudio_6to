package Pojo;

public class cliente {

    String Ncliente;
    String Nmascota;
    String raza;
    String Year;
    String Telefono;

    public String getNcliente() {
        return Ncliente;
    }

    public void setNcliente(String ncliente) {
        Ncliente = ncliente;
    }

    public String getNmascota() {
        return Nmascota;
    }

    public void setNmascota(String nmascota) {
        Nmascota = nmascota;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        Telefono = telefono;
    }
}
