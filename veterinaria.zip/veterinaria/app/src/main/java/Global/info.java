package Global;

import java.util.ArrayList;

import Pojo.cliente;

public class info {
    public static final ArrayList<cliente> Lista = new ArrayList<>();
}
